# Appmaker Starter App
Docs: https://developer-docs.appmaker.xyz