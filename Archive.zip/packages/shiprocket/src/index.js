import { getCheckout } from './lib/api.js';
import { appmaker, appmakerFunctions } from '@appmaker-xyz/core';
import OneClickCheckout from './pages/oneclickcheckout.js';
import { customPaymentSchema } from './lib/oneclick';
const Plugin = {
  id: 'shiprocket',
  name: 'Shiprocket',
  activate,
  pages: {
    OneClickCheckout,
  },
};

export function activate() {
 console.log('activated one click checkout');
  appmakerFunctions.registerAppmakerFn({
    trigger: 'before-open-checkout', // hook to trigger before opening checkout
    namespace: 'oneclick-update-checkout',// namespace for the function
    fn: getCheckout, // map to the function that will be called
  });
  appmaker.addFilter(
    'webview-custom-url-filters', // hook to add custom url filters
    'oneclick-payment-url-filters', // namespace for the filter
    (currentFilters) => {
      return [...currentFilters, customPaymentSchema]; // add the filter to the list of filters
    },
  );
}
appmaker.registerPlugin(Plugin);
export default Plugin;
// activateLocalExtension(
//   {"id":"shiprocket","settings":{}});
// activate();



// import { appmaker } from '@appmaker-xyz/core';
// import React from 'react';
// import { View, Text, Button } from 'react-native';

// export function activate(params) {
//   console.log('shiprocket activated with config', params);
//   return(
//     <Text>Custom Block</Text>
//   )
// }
// const Shiprocket = {
//   id: 'shiprocket',
//   activate,
// };
// appmaker.registerPlugin(Shiprocket);
// export default Shiprocket;
